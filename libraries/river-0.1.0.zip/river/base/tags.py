TEXT_INPUT = "text input"
POSITIVE_INPUT = "positive input"
