class MultiOutputMixin:
    """A multi-output estimator."""
